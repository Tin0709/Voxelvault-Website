---
name: Atelier Monolith
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#bccac0'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#87948b'
  outline-variant: '#3d4a42'
  surface-tint: '#68dba9'
  primary: '#68dba9'
  on-primary: '#003825'
  primary-container: '#25a475'
  on-primary-container: '#00311f'
  inverse-primary: '#006c4a'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#8bd6b4'
  on-tertiary: '#003827'
  tertiary-container: '#559f80'
  on-tertiary-container: '#003121'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#85f8c4'
  primary-fixed-dim: '#68dba9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#005137'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#a6f2cf'
  tertiary-fixed-dim: '#8bd6b4'
  on-tertiary-fixed: '#002115'
  on-tertiary-fixed-variant: '#00513a'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  display-lg:
    fontFamily: Outfit
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Outfit
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 42px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Outfit
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style
The design system establishes a gallery-grade visual discovery and patronage space dedicated to monumental voxel architecture, complex world downloads, and spatial digital artifacts. It deliberately strips away juvenile gaming clichés, blocky bevels, and hyper-saturated novelty in favor of quiet luxury, structural restraint, and high-fidelity curation.

The aesthetic fuses architectural minimalism with high-end digital publishing. Obsidian monolith surfaces, hairline geometric divisions, and generous vacuum space direct total focus toward structural form, light, and materiality. Subtle deep-moss accents evoke geological organic strata and the lineage of the virtual canvas without resorting to overt pixelation. The interface conveys permanence, precision, and institutional prestige—treating digital builders as master architects and patron collectives as fine-art patrons.

## Colors
The palette is rooted in an abyss of dark obsidian neutrals accented by quiet, high-resonance geological emerald tones. 

- **Primary Neutral (`#09090B`)**: Serves as the canvas base floor. Surface layers step upward through strict zinc tonal increments: Surface Base (`#09090B`), Surface Elevated (`#121215`), Surface Container (`#18181B`), and Surface Overlay (`#222226`).
- **Primary Accent (`#059669`)**: A deep, architectonic moss used with extreme restraint for primary commitments, active tier selections, verified architectural seals, and focus anchors.
- **Secondary Accent (`#10B981`)**: A vibrant emerald used exclusively for hover illumination, active state feedback, and micro-metrics (e.g., world seed copy confirmation, schematic download triggers).
- **Tertiary Accent (`#A7F3D0`)**: A pale jade luminescence reserved for high-legibility badges, subtle glows, and low-opacity status pills over dark imagery.
- **Text Tiers**:
  - Primary Text: `#F4F4F5` (Zinc 100) — high-contrast clarity for headers and structural labels.
  - Secondary Text: `#A1A1AA` (Zinc 400) — technical telemetry, creator monikers, metadata.
  - Tertiary Text: `#52525B` (Zinc 600) — structural timestamps, perimeter grid numbers, coordinate indicators.

## Typography
Typography balances the architectural purity of `Outfit` with the high-legibility, systematic modernism of `Hanken Grotesk`. 

- **Display & Headlines (`Outfit`)**: Employed for architectural scale titles, build designations, and manifest headers. Clean curves and geometric precision give headers an editorial, monograph appearance.
- **Body & Labels (`Hanken Grotesk`)**: Utilized for manifest descriptions, build coordinates, version specs, and patron tiers. Delivers pristine micro-legibility at compact sizes across data-dense specs.
- **Case Conventions**: Technical metadata, voxel dimensions, and spatial categories rely on `label-sm` set to uppercase with deliberate tracking (`0.06em`) to echo architectural drafting blueprints.

## Layout & Spacing
The layout employs an asymmetric, responsive masonry grid calibrated for high-density spatial showcases alongside generous architectural negative space.

- **Masonry Structure**: Content cards distribute across a dynamic multi-column masonry flow: 2 columns on mobile (`<640px`), 3 columns on tablet (`641px–1024px`), 4 columns on desktop (`1025px–1600px`), and 5 columns on ultra-wide screens (`>1600px`). Masonry heights adjust organically based on card imagery aspect ratios (ranging from 4:5 vertical frames to 16:9 cinematic expanses).
- **Rhythm & Alignments**: Structural margins frame the entire canvas with gallery-like breathing room (`2.5rem` desktop, `1.25rem` mobile). Elements never crowd the screen perimeter. Column gutters maintain strict visual isolation (`1.5rem`), ensuring complex architectural imagery does not visually bleed into adjacent works.
- **Docking & Glass Rails**: Primary discovery controls and patronage quick-actions float via detached, centered capsules suspended over the canvas bottom or pinned cleanly across the top navigation axis.

## Elevation & Depth
Elevation eschews conventional high-contrast drop shadows in favor of ambient luminescence, tonal surface shifts, and frosted optical filters.

- **Surface Tiers**: Hierarchy is achieved primarily through surface shifts:
  - Level 0 (Canvas): `#09090B` (solid obsidian base).
  - Level 1 (Masonry Tiles & Panels): `#121215` with a subtle hairline boundary (`1px solid rgba(255, 255, 255, 0.06)`).
  - Level 2 (Floating Action Pills & Modals): `#18181B` with `backdrop-filter: blur(24px)` at 85% opacity.
- **Glassmorphic Shields**: Floating navigation capsules, category selectors, and patron pledge widgets utilize semi-translucent dark obsidian fills (`rgba(18, 18, 21, 0.72)`) complemented by a micro inner top border (`inset 0 1px 0 0 rgba(255, 255, 255, 0.12)`) and a diffuse ambient shadow (`0 20px 40px -15px rgba(0, 0, 0, 0.7)`).
- **Emerald Backlight**: On active card hover or selected patron tier cards, a localized emerald radiation (`box-shadow: 0 0 30px -10px rgba(5, 150, 105, 0.22)`) emanates smoothly, providing visceral, modern tactile feedback.

## Shapes
The design system pairs structural, razor-sharp architectural layout grids with softly tailored, rounded geometry:

- **Base Radius (`roundedness: 2`)**: Component primitives—including input fields, compact buttons, and tags—utilize an intentional `0.5rem` (`8px`) corner radius.
- **Large Surfaces (`rounded-lg` / `rounded-xl`)**: Primary masonry build cards, patronage comparison slabs, and presentation viewports take `1rem` (`16px`) to `1.5rem` (`24px`) radii, providing a contemporary, tactile silhouette that softens the rigid rectilinear nature of voxel builds.
- **Action Capsules**: Omnipresent floating toolbars, category filters, and persistent support pills employ a continuous pill treatment (`9999px`), distinguishing actionable floating chrome from static spatial exhibits.

## Components

### Buttons & Interactive Pills
- **Primary Commitment Button**: Solid `#059669` fill, high-contrast `#F4F4F5` label, subtle emerald ambient glow on hover, transition speed 200ms cubic-bezier(0.16, 1, 0.3, 1).
- **Ghost Surface Action**: Background `rgba(255, 255, 255, 0.04)`, hairline border `1px solid rgba(255, 255, 255, 0.08)`. On hover, shifts to `rgba(255, 255, 255, 0.08)` and border becomes `rgba(16, 185, 129, 0.4)`.
- **Floating Action Pill**: Pinned centered floating controls with blurred obsidian backing, containing iconography and concise micro-labels (`label-sm`).

### Masonry Cards
- **Structure**: Rounded-2xl container (`16px`), overflow hidden, base background `#121215`.
- **Imagery**: Displays high-res renders or world screenshots. Default state shows unadorned structural beauty. On hover, the image scales subtly (1.025x), revealing an integrated bottom glassmorphic gradient overlay displaying the project title, creator avatar, schematic version, and quick-download action pill.
- **Badges**: Floating top-left tags (`label-sm`) with dark glass backgrounds, presenting voxel dimensions or world download formats (.schem, .world).

### Input Fields & Search Bars
- **Surface**: Inset `#09090B` or elevated `#18181B` field with a `1px solid rgba(255, 255, 255, 0.08)` perimeter. 
- **Focus State**: Border transitions to `#059669` with an ultra-soft `0 0 0 3px rgba(5, 150, 105, 0.15)` focus ring. Placeholder text set to `#52525B`.

### Creator Tiers & Patronage Slabs
- **Format**: Vertical architectural monolith cards.
- **Details**: Distinct monthly contribution metric in `Outfit` (`headline-lg`), followed by an architectural bulleted index of patron benefits (e.g., raw world files, schematic files, private Discord build reviews).
- **Active / Featured Tier**: Outlined with a continuous hairline border in `#059669`, accompanied by a Tertiary Accent (`#A7F3D0`) pill badge marking "Architect Patron."

### Selection Controls (Checkboxes & Radios)
- Custom minimal boxes with dark obsidian centers and hairline gray borders. Checked states fill with `#059669` and reveal a crisp geometric check or dot in pure `#FFFFFF`.